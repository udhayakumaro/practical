int switches();
