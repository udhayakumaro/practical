int blink();
